
#include <stdio.h>

int main()
{
    int a,b,c;
    a=b=c=3;
    int product;
    product=a*b*c;
    
    printf("The product of three variables is %d",product);
    
    return 0;
}
