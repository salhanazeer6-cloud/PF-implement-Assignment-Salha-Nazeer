
#include <stdio.h>

int main()
{
   int a=10,b=20;
   int sum;
   float average;
  
   sum=a+b;
   average=sum/2.0;
   
   printf("The average of those values is %.2f" ,average);
   
    return 0;
}
