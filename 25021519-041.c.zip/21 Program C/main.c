
#include <stdio.h>

int main()
{
    printf(" XXXXX ");
    printf("\n XXXX");
    printf("\n XXX");
    printf("\n XX");
    printf("\n X");
    
    return 0;
}
