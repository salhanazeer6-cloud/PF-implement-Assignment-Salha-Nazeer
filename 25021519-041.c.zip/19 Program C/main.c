
#include <stdio.h>

int main()
{
   int age,months,days;
   age=18;
   
   months=age*12;
   days=age*365;
   
   printf("The age in months is %d",months);
   printf("\n The age in days is %d",days);
   
    return 0;
}
