
#include <stdio.h>

int main()
{
   int a,b,sum,product;
   
   printf("Enter first number ",a);
   scanf("%d",&a);
   
   printf("Enter second number ",b);
    scanf("%d",&b);
    
    sum=a+b;
    product=a*b;
    
    printf("The sum of two numbers is %d \n",sum);
    printf("The product of two numbers is %d \n",product);
    
    return 0;
}
