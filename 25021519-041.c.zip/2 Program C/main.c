
#include <stdio.h>

int main()
{
    printf("C is a powerful programming language");

    return 0;
}