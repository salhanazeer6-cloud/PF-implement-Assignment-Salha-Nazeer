
#include <stdio.h>

int main()
{
   int y=2,months;
   months=y*12;
   
   printf("The number of months in %d are %d",y,months);
   
   return 0;
}