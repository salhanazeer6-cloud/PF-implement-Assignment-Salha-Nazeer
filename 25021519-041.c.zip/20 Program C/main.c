
#include <stdio.h>

int main()
{
    printf("C:\ Windows>");
    printf("\n'P' 'A' 'K'");
    printf("\nPakistan");

    return 0;
}
