
#include <stdio.h>

int main()
{
    int a,vi,t;
    float S;
    vi=200;
    t=70;
    
    S=vi * t + 0.5 * a * t * t;
    printf("The value of S is %.2f",S);

    return 0;
}
