
#include <stdio.h>

int main()
{
    int a=10, b=6, c=5;
    
    printf("The value of a is %d\n",a);
 
    printf("The value of b is %d\n",b);
      
    printf("The value of c is %d\n",c);

    return 0;
}