
#include <stdio.h>

int main()
{
   int years,months;
   
   printf("Enter the age in years:\n");
   scanf("%d",&years);
   
   months=years*12;
   printf("The age in months is %d",months);

    return 0;
}
