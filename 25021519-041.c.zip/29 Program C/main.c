
#include <stdio.h>

int main()
{
    int n;
    printf("Enter the number:");
    scanf("%d",&n);
    
    if(n>100)
    printf("number is greater than 100");

    return 0;
}
